export interface user {
    
    firstname: string;
    lastname: string;
    email: string;
    password: string;
    phoneNumber: string;
    location: string;
    department: string;
    roles: string;


}
