// import { Injectable } from '@angular/core';

// @Injectable({
//   providedIn: 'root'
// })
// export class AuthService {
//   register(value: Partial<{ firstname: string | null; lastname: string | null; email: string | null; password: string | null; phoneNumber: string | null; location: string | null; department: string | null; roles: string | null; }>) {
//     throw new Error('Method not implemented.');
//   }

//   constructor() { }
//}



import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private baseUrl = 'http://localhost:8080/api'; // Need to Update with running backend URL

  constructor(private http: HttpClient) { }

  register(user: any): Observable<any> {
    return this.http.post(`${this.baseUrl}/register`, user);
  }
}
